package com.example.vpvu2.androidpizza.Common;

import com.example.vpvu2.androidpizza.Model.User;

/**
 * Created by VPVU2 on 10/9/2017.
 */

public class Common {
    public static User currentUser;
}
