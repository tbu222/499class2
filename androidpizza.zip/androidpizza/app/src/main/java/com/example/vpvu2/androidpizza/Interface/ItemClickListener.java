package com.example.vpvu2.androidpizza.Interface;

import android.view.View;

/**
 * Created by VPVU2 on 10/9/2017.
 */

public interface ItemClickListener {
    void onClick(View view, int position, boolean isLongClick);

}
