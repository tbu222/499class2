package com.example.vpvu2.androidpizza.ViewHolder;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.vpvu2.androidpizza.Interface.ItemClickListener;
import com.example.vpvu2.androidpizza.MapsActivity;
import com.example.vpvu2.androidpizza.OrderStatusInfo;
import com.example.vpvu2.androidpizza.R;

import org.w3c.dom.Text;


/**
 * Created by thinh on 10/31/2017.
 */

public class OrderViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    public TextView orderID,orderStatus, orderPhone, orderAddress, orderETA, timePlacement;
    public Button orderTrack, orderCancel;
    long timeAtCancel, placementTime;
    private ItemClickListener itemClickListener;

    public OrderViewHolder(View itemView) {
        super(itemView);
        orderAddress = (TextView)itemView.findViewById(R.id.order_address);
        orderPhone = (TextView)itemView.findViewById(R.id.order_phone);
        orderStatus = (TextView)itemView.findViewById(R.id.order_status);
        orderID = (TextView)itemView.findViewById(R.id.order_id);
        orderETA = (TextView)itemView.findViewById(R.id.order_eta);
        orderTrack = (Button)itemView.findViewById(R.id.track_map);
        orderCancel = (Button)itemView.findViewById(R.id.cancel_order);
        timePlacement = (TextView)itemView.findViewById(R.id.time_placement);

        orderTrack.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent goToMap = new Intent(v.getContext(), MapsActivity.class);
                v.getContext().startActivity(goToMap);
            }
        });

        orderCancel.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                //check to see if within 30 seconds of placement
                timeAtCancel = System.currentTimeMillis();
                placementTime = Integer.parseInt((String)timePlacement.getText());

                //calculate here
                //if 30 seconds or less:
                //print successful cancel and refund money
                //else:
                               AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(v.getContext());

                                final EditText et = new EditText(v.getContext());

                                // set prompts.xml to alertdialog builder
                                alertDialogBuilder.setView(et);

                                // set dialog message
                                alertDialogBuilder.setMessage("Too late to cancel order.");
                                alertDialogBuilder.setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                    }
                                });

                                // create alert dialog
                                AlertDialog alertDialog = alertDialogBuilder.create();
                                // show it
                                alertDialog.show();

            }
        });


    }

    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    @Override
    public void onClick(View view) {
            itemClickListener.onClick(view,getAdapterPosition(),false);
    }
}
